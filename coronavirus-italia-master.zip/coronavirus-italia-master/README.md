# coronavirus-italia 
Per sorgenti dati vedi: https://github.com/pcm-dpc/COVID-19

##Impara a programmare in javascript con i miei corsi su demy: www.hidran.it
Dati regionali corona virus

lanciare npm i per installare le dipendenze

`npm run dev` per buildare  dev

`npm run build` per buildare production

`npm deploy` per la deploy su github pages
